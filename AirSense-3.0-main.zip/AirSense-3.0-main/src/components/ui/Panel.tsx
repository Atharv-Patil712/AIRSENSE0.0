import type { ReactNode } from 'react';

interface PanelProps {
  title?: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
  flush?: boolean;
}

/**
 * The standard content container: one level of chrome only.
 * Section → important metric → supporting information.
 */
export function Panel({
  title,
  description,
  actions,
  children,
  className = '',
  bodyClassName = '',
  flush = false,
}: PanelProps) {
  const hasHeader = Boolean(title || actions);
  return (
    <section className={`surface shadow-panel ${className}`}>
      {hasHeader && (
        <header className="flex items-start justify-between gap-3 px-5 pt-4 pb-3">
          <div className="min-w-0">
            {title && (
              <h2 className="font-display text-[15px] font-semibold tracking-tight leading-5">{title}</h2>
            )}
            {description && <p className="text-xs text-muted mt-0.5">{description}</p>}
          </div>
          {actions && <div className="flex items-center gap-1.5 flex-shrink-0">{actions}</div>}
        </header>
      )}
      <div className={`${flush ? '' : hasHeader ? 'px-5 pb-5' : 'p-5'} ${bodyClassName}`}>
        {children}
      </div>
    </section>
  );
}