import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export type MetricTone = 'neutral' | 'green' | 'yellow' | 'orange' | 'red' | 'blue';

interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  trend?: 'up' | 'down' | 'stable';
  trendLabel?: string;
  tone?: MetricTone;
  subtitle?: string;
}

const toneValueClass: Record<MetricTone, string> = {
  neutral: '',
  green: 'text-success-600',
  yellow: 'text-warning-600',
  orange: 'text-[var(--color-warning)]',
  red: 'text-danger-600',
  blue: 'text-[var(--color-primary-text)]',
};

const toneDotClass: Record<MetricTone, string> = {
  neutral: 'bg-[var(--color-border-strong)]',
  green: 'bg-success-500',
  yellow: 'bg-warning-500',
  orange: 'bg-[var(--color-warning)]',
  red: 'bg-danger-500',
  blue: 'bg-accent-500',
};

/**
 * A single important metric — no icon boxes, no nested cards.
 * Label → authoritative value → supporting information.
 */
export function StatCard({
  label,
  value,
  unit,
  trend,
  trendLabel,
  tone = 'neutral',
  subtitle,
}: StatCardProps) {
  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus;
  // For environmental data: rising values mean worsening conditions
  const trendClass =
    trend === 'up' ? 'text-danger-500' : trend === 'down' ? 'text-success-500' : 'text-muted';

  return (
    <div className="flex flex-col">
      <div className="flex items-center gap-1.5 mb-2">
        <span className={`status-dot ${toneDotClass[tone]}`} />
        <span className="kicker">{label}</span>
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className={`metric-value text-[26px] leading-none ${toneValueClass[tone]}`}>
          {value}
        </span>
        {unit && <span className="text-xs text-muted font-medium">{unit}</span>}
        {trend && (
          <span className={`inline-flex items-center gap-0.5 text-xs font-medium ml-auto ${trendClass}`}>
            <TrendIcon className="w-3 h-3" />
            {trendLabel}
          </span>
        )}
      </div>
      {subtitle && (
        <p className="text-[11.5px] text-muted mt-1.5 truncate">{subtitle}</p>
      )}
    </div>
  );
}
