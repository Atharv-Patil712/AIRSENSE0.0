import { useState, useEffect } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Menu, Search, MapPin, LogOut, ChevronDown, Sun, Moon, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { navGroups } from '@/config/navigation';
import { CommandPalette } from '@/components/layout/CommandPalette';
import { kbdLabel } from '@/lib/platform';
import { NotificationCenter } from '@/components/layout/NotificationCenter';
import { AirSenseLogo } from '@/components/brand/AirSenseMark';

export function DashboardLayout() {
  const { user, profile, signOut } = useAuth();
  const { isDark, setTheme } = useTheme();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);

  // Global ⌘K / Ctrl+K opens the command palette
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  // Close profile menu on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('[data-profile-menu]')) setShowProfile(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="dashboard-shell min-h-screen bg-[var(--color-bg)] flex">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-[232px] bg-[var(--color-surface)] border-r border-[var(--color-border)] transform transition-transform duration-250 ease-out lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-14 flex items-center justify-between px-4 border-b border-[var(--color-border)]">
          <AirSenseLogo size="sm" />
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-1 rounded-md hover:bg-[var(--color-surface-2)]"
            aria-label="Close menu"
          >
            <X className="w-4 h-4 text-muted" />
          </button>
        </div>

        <nav className="px-3 py-4 space-y-5 overflow-y-auto h-[calc(100vh-3.5rem)] scrollbar-thin">
          {navGroups.map((group) => (
            <div key={group.label}>
              <p className="kicker px-2 mb-1.5">{group.label}</p>
              <ul className="space-y-px">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  return (
                    <li key={item.to}>
                      <NavLink
                        to={item.to}
                        onClick={() => setSidebarOpen(false)}
                        className={({ isActive }) =>
                          `relative flex items-center gap-2.5 pl-3 pr-2 py-[7px] rounded-md text-[13px] transition-colors duration-150 ${
                            isActive
                              ? 'bg-[var(--color-primary-soft)] text-[var(--color-primary-text)] font-medium'
                              : 'text-secondary hover:bg-[var(--color-surface-2)] hover:text-[var(--color-text)]'
                          }`
                        }
                      >
                        {({ isActive }) => (
                          <>
                            {isActive && (
                              <span className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-4 rounded-full bg-primary-500" />
                            )}
                            <Icon
                              className="w-4 h-4 flex-shrink-0"
                              strokeWidth={isActive ? 2 : 1.75}
                            />
                            {item.label}
                          </>
                        )}
                      </NavLink>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}

        </nav>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 lg:hidden animate-overlay-in"
          style={{ background: 'var(--overlay)' }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main column */}
      <div className="flex-1 lg:ml-[232px] min-w-0 flex flex-col">
        {/* Top bar */}
        <header className="h-14 sticky top-0 z-20 bg-[var(--color-surface)] border-b border-[var(--color-border)] flex items-center px-4 sm:px-6 gap-3">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-1.5 -ml-1.5 rounded-md hover:bg-[var(--color-surface-2)]"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5" strokeWidth={1.75} />
          </button>

          {/* Command palette trigger */}
          <button
            onClick={() => setPaletteOpen(true)}
            className="flex items-center gap-2 w-full max-w-sm min-w-0 h-[32px] px-2.5 rounded-md border border-[var(--color-border-strong)] bg-transparent text-left transition-colors hover:border-[var(--color-text-muted)]"
            aria-label={`Open search (${kbdLabel})`}
          >
            <Search className="w-3.5 h-3.5 text-muted flex-shrink-0" strokeWidth={1.75} />
            <span className="text-[13px] text-muted truncate flex-1">Search…</span>
            <kbd className="mono-label uppercase text-muted border border-[var(--color-border)] rounded px-1 py-px hidden sm:block">
              {kbdLabel}
            </kbd>
          </button>

          <div className="flex-1" />

          {/* Region */}
          <div className="hidden md:flex items-center gap-1.5 text-xs text-muted">
            <MapPin className="w-3.5 h-3.5" strokeWidth={1.75} />
            India
          </div>

          <div className="w-px h-5 bg-[var(--color-border)] hidden md:block" />

          {/* Theme */}
          <button
            onClick={() => setTheme(isDark ? 'light' : 'dark')}
            className="btn-ghost !p-2"
            title="Toggle theme"
            aria-label="Toggle theme"
          >
            {isDark ? (
              <Sun className="w-4 h-4" strokeWidth={1.75} />
            ) : (
              <Moon className="w-4 h-4" strokeWidth={1.75} />
            )}
          </button>

          {/* Notifications */}
          <NotificationCenter />

          {/* Profile */}
          <div data-profile-menu className="relative">
            <button
              onClick={() => setShowProfile(!showProfile)}
              className="flex items-center gap-1.5 p-1 rounded-md hover:bg-[var(--color-surface-2)] transition-colors"
              aria-expanded={showProfile}
              aria-label="Account menu"
            >
              <span className="w-7 h-7 rounded-full grid place-items-center text-[12px] font-semibold border border-[var(--color-border-strong)] bg-[var(--color-surface-2)] text-secondary">
                {(profile?.full_name || user?.email || 'U').charAt(0).toUpperCase()}
              </span>
              <ChevronDown
                className={`w-3.5 h-3.5 text-muted hidden sm:block transition-transform duration-150 ${
                  showProfile ? 'rotate-180' : ''
                }`}
              />
            </button>
            {showProfile && (
              <div className="absolute top-full right-0 mt-1.5 w-56 surface shadow-popover z-50 py-1 animate-fade-in">
                <div className="px-3.5 py-3 border-b border-[var(--color-border)]">
                  <p className="text-[13px] font-medium">{profile?.full_name || 'User'}</p>
                  <p className="text-[11px] text-muted truncate mt-0.5">{user?.email}</p>
                </div>
                <div className="p-1">
                  <NavLink
                    to="/settings"
                    onClick={() => setShowProfile(false)}
                    className="flex items-center gap-2 px-2.5 py-1.5 rounded-md hover:bg-[var(--color-surface-2)] text-[13px] transition-colors"
                  >
                    Settings
                  </NavLink>
                  <button
                    onClick={handleSignOut}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md hover:bg-[var(--color-surface-2)] text-[13px] text-danger-500 transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" strokeWidth={1.75} /> Sign out
                  </button>
                </div>
              </div>
            )}
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 px-4 sm:px-6 py-5 sm:py-6">
          <Outlet />
        </main>
      </div>

      {/* Global command palette */}
      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
    </div>
  );
}
