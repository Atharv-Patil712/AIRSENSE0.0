import { useEffect, useState, Fragment, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, ArrowDown, ArrowUp, SlidersHorizontal } from 'lucide-react';
import {
  LineChart,
  Line,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Area,
  AreaChart,
} from 'recharts';
import { methaneService } from '@/services/methaneService';
import { aqiService } from '@/services/aqiService';
import { weatherService } from '@/services/weatherService';
import { alertService } from '@/services/alertService';
import { aiService } from '@/services/aiService';
import type { Hotspot, AqiObservation, WeatherObservation, EnvironmentalAlert } from '@/types';
import { StatCard } from '@/components/ui/StatCard';
import { DemoBadge } from '@/components/ui/DemoBadge';
import { PageHeader } from '@/components/ui/PageHeader';
import { Panel } from '@/components/ui/Panel';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { FreshnessStamp } from '@/components/ui/FreshnessStamp';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { usePageTitle } from '@/hooks/usePageTitle';
import { timeAgo } from '@/lib/format';
import {
  CHART_COLORS,
  chartTick,
  chartAxisLine,
  chartGridStroke,
  tooltipContentStyle,
  tooltipItemStyle,
  tooltipLabelStyle,
} from '@/components/ui/chartTheme';
import { getAqiCategory, RISK_COLORS, SEVERITY_COLORS, SOURCE_TYPE_LABELS } from '@/data/indiaData';

/** Customizable dashboard sections, in display order. */
type SectionId = 'status' | 'map' | 'trends' | 'hotspots' | 'weather' | 'insight';

const SECTION_LABELS: Record<SectionId, string> = {
  status: 'Key metrics',
  map: 'Map & alert feed',
  trends: 'Trend charts',
  hotspots: 'Hotspot ranking',
  weather: 'Weather conditions',
  insight: 'AI insight',
};

const DEFAULT_ORDER: SectionId[] = ['status', 'map', 'trends', 'hotspots', 'weather', 'insight'];

interface DashboardLayoutPrefs {
  order: SectionId[];
  hidden: SectionId[];
}

export function DashboardPage() {
  usePageTitle('Dashboard');
  const navigate = useNavigate();
  const [hotspots, setHotspots] = useState<Hotspot[]>([]);
  const [aqiData, setAqiData] = useState<AqiObservation[]>([]);
  const [weatherData, setWeatherData] = useState<WeatherObservation[]>([]);
  const [alerts, setAlerts] = useState<EnvironmentalAlert[]>([]);
  const [isDemo, setIsDemo] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadedAt, setLoadedAt] = useState<Date>(new Date());
  const [methaneTrend, setMethaneTrend] = useState<{ date: string; value: number }[]>([]);
  const [aqiTrend, setAqiTrend] = useState<{ date: string; aqi: number }[]>([]);
  const [customizeOpen, setCustomizeOpen] = useState(false);
  const [layout, setLayout] = useLocalStorage<DashboardLayoutPrefs>('airsense-dashboard-sections', {
    order: DEFAULT_ORDER,
    hidden: [],
  });

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      const [hsRes, aqiRes, wxRes, alertRes] = await Promise.all([
        methaneService.getHotspots(),
        aqiService.getAqiObservations(),
        weatherService.getWeatherObservations(),
        alertService.getAlerts(),
      ]);

      setHotspots(hsRes.data);
      setAqiData(aqiRes.data);
      setWeatherData(wxRes.data);
      setAlerts(alertRes.data);
      setIsDemo(hsRes.isDemo || aqiRes.isDemo || wxRes.isDemo);
      setLoadedAt(new Date());

      if (hsRes.data.length > 0) {
        const trend = await methaneService.getMethaneTrend(
          hsRes.data[0].latitude,
          hsRes.data[0].longitude,
          30,
          hsRes.data[0].methane_index,
          42,
        );
        setMethaneTrend(trend.data);
      }
      if (aqiRes.data.length > 0) {
        const trend = await aqiService.getAqiTrend(aqiRes.data[0].city, 30);
        setAqiTrend(trend.data);
      }
      setLoading(false);
    }
    loadData();
  }, []);

  const visibleOrder = (layout.order.length === DEFAULT_ORDER.length ? layout.order : DEFAULT_ORDER).filter(
    (id) => !layout.hidden.includes(id),
  );

  const toggleSection = (id: SectionId) => {
    setLayout((prev) => ({
      ...prev,
      hidden: prev.hidden.includes(id) ? prev.hidden.filter((h) => h !== id) : [...prev.hidden, id],
    }));
  };

  const moveSection = (id: SectionId, dir: -1 | 1) => {
    setLayout((prev) => {
      const order = prev.order.length === DEFAULT_ORDER.length ? [...prev.order] : [...DEFAULT_ORDER];
      const i = order.indexOf(id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= order.length) return prev;
      [order[i], order[j]] = [order[j], order[i]];
      return { ...prev, order };
    });
  };

  if (loading) return <LoadingSpinner label="Loading environmental data…" />;


  const activeHotspots = hotspots.filter((h) => h.risk_level === 'high' || h.risk_level === 'critical').length;
  const highestMethane = Math.max(...hotspots.map((h) => h.methane_index), 0);
  const peakLocation = hotspots.reduce<Hotspot | null>((max, h) => (!max || h.methane_index > max.methane_index ? h : max), null);
  const currentAqi = aqiData[0]?.aqi ?? 0;
  const aqiCat = getAqiCategory(currentAqi);
  const mostPolluted = aqiData.reduce((max, a) => (a.aqi > max.aqi ? a : max), aqiData[0] ?? { city: 'N/A', aqi: 0, state: '' });
  const currentWeather = weatherData[0];
  const aiResult = hotspots[0]
    ? aiService.analyze({ hotspot: hotspots[0], aqi: aqiData[0] ?? null, weather: currentWeather ?? null })
    : null;
  const sortedHotspots = [...hotspots].sort((a, b) => b.methane_index - a.methane_index);

  const cell = 'bg-[var(--color-surface)] p-5';

  // ── Section renderers — order & visibility are user-configurable ──
  const renderSection: Record<SectionId, () => ReactNode> = {

  // Key metrics
  status: () => (
    <section className="surface shadow-panel overflow-hidden">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-[var(--color-border)]">
          <div className={`${cell} col-span-2 lg:col-span-1`}>
            <div className="flex items-center gap-1.5 mb-2">
              <span className="status-dot" style={{ backgroundColor: aqiCat.color }} />
              <span className="kicker">Current AQI · {aqiData[0]?.city ?? '—'}</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="metric-value text-[30px] leading-none" style={{ color: aqiCat.color }}>
                {currentAqi}
              </span>
              <span className="text-xs font-medium" style={{ color: aqiCat.color }}>
                {aqiCat.label}
              </span>
            </div>
            <p className="text-[11.5px] text-muted mt-1.5">Worst: {mostPolluted.city} · {mostPolluted.aqi}</p>
          </div>

          <div className={cell}>
            <StatCard
              label="Active hotspots"
              value={activeHotspots}
              tone={activeHotspots > 6 ? 'red' : activeHotspots > 3 ? 'orange' : 'green'}
              subtitle={`${hotspots.length} tracked sites`}
            />
          </div>

          <div className={cell}>
            <StatCard
              label="Peak methane"
              value={highestMethane}
              unit="ppb"
              tone={highestMethane > 2200 ? 'red' : highestMethane > 2000 ? 'orange' : 'green'}
              subtitle={peakLocation ? peakLocation.name : undefined}
            />
          </div>

          <div className={cell}>
            <StatCard
              label="Composite risk"
              value={aiResult?.riskScore ?? 0}
              unit="/100"
              tone={
                aiResult?.riskLevel === 'critical'
                  ? 'red'
                  : aiResult?.riskLevel === 'high'
                    ? 'orange'
                    : 'green'
              }
              subtitle={aiResult ? `${aiResult.riskLevel} risk · model v1` : 'Calculating…'}
            />
          </div>
        </div>
      </section>
  ),

  // Map centerpiece + alert feed
  map: () => (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Panel
          className="lg:col-span-2 animate-fade-up"
          title="Methane hotspots & AQI stations"
          description="Geographic distribution across the monitoring region"
          actions={
            <Link to="/map" className="link text-xs inline-flex items-center gap-1">
              Full map <ArrowRight className="w-3 h-3" />
            </Link>
          }
        >
          <div className="rounded-lg overflow-hidden border border-[var(--color-border)]">
            <MiniMapPreview hotspots={hotspots} aqiData={aqiData} />
          </div>
        </Panel>

        <Panel
          title="Alert feed"
          description={`${alerts.length} in network`}
          actions={
            <Link to="/alerts" className="link text-xs">
              All alerts
            </Link>
          }
          bodyClassName="!px-0 !pb-1"
          className="animate-fade-up"
        >
          <ul className="divide-rule max-h-[324px] overflow-y-auto scrollbar-thin">
            {alerts.slice(0, 6).map((alert) => (
              <li
                key={alert.id}
                className="px-5 py-3 hover:bg-[var(--color-surface-2)] transition-colors flex items-start gap-3 cursor-pointer"
                onClick={() => navigate('/alerts')}
              >
                <span
                  className="status-dot mt-[7px]"
                  style={{
                    backgroundColor: SEVERITY_COLORS[alert.severity],
                    opacity: alert.is_read ? 0.4 : 1,
                  }}
                />
                <div className="min-w-0 flex-1">
                  <p className={`text-[13px] truncate ${alert.is_read ? 'text-secondary' : 'font-medium'}`}>
                    {alert.location_name}
                    {!alert.is_read && (
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary-500 ml-2 -mt-px" aria-label="Unread" />
                    )}
                  </p>
                  <p className="text-xs text-muted line-clamp-1 mt-px">{alert.reason}</p>
                  <p className="mono-label uppercase text-muted mt-1.5">
                    {alert.severity} · {timeAgo(alert.triggered_at)}
                  </p>
                </div>
              </li>
            ))}
            {alerts.length === 0 && (
              <li className="px-5 py-10 text-center text-sm text-muted">No active alerts</li>
            )}
          </ul>
        </Panel>
      </div>
  ),

  // Trends
  trends: () => (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel
          title="AQI trend"
          description={`${aqiData[0]?.city ?? 'Network'} · last 30 days`}
          className="animate-fade-up"
        >
          <ResponsiveContainer width="100%" height={190}>
            <LineChart data={aqiTrend} margin={{ top: 4, right: 8, bottom: 0, left: -22 }}>
              <CartesianGrid stroke={chartGridStroke} vertical={false} />
              <XAxis dataKey="date" tick={chartTick} axisLine={chartAxisLine} tickLine={false} interval={6} dy={4} />
              <YAxis tick={chartTick} axisLine={false} tickLine={false} width={44} />
              <Tooltip
                contentStyle={tooltipContentStyle}
                itemStyle={tooltipItemStyle}
                labelStyle={tooltipLabelStyle}
                cursor={{ stroke: 'var(--color-border-strong)' }}
              />
              <Line
                type="monotone"
                dataKey="aqi"
                stroke={CHART_COLORS.primary}
                strokeWidth={1.75}
                dot={(props) => (
                  <circle key={props.key} cx={props.cx} cy={props.cy} r={2.5}
                    fill={getAqiCategory(props.payload.aqi).color} stroke="var(--color-surface)" strokeWidth={1} />
                )}
                name="AQI"
                activeDot={{ r: 3, strokeWidth: 0 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Panel>

        <Panel
          title="Methane trend"
          description={`${peakLocation?.name ?? 'Region'} · last 30 days`}
          actions={isDemo ? <DemoBadge show={true} /> : undefined}
          className="animate-fade-up"
        >
          <ResponsiveContainer width="100%" height={190}>
            <AreaChart data={methaneTrend} margin={{ top: 4, right: 8, bottom: 0, left: -14 }}>
              <defs>
                <linearGradient id="methaneGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={CHART_COLORS.primarySoft} />
                  <stop offset="100%" stopColor={CHART_COLORS.primary} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke={chartGridStroke} vertical={false} />
              <XAxis dataKey="date" tick={chartTick} axisLine={chartAxisLine} tickLine={false} interval={6} dy={4} />
              <YAxis tick={chartTick} axisLine={false} tickLine={false} width={36} domain={['dataMin - 40', 'dataMax + 40']} />
              <Tooltip
                contentStyle={tooltipContentStyle}
                itemStyle={tooltipItemStyle}
                labelStyle={tooltipLabelStyle}
                cursor={{ stroke: 'var(--color-border-strong)' }}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke={CHART_COLORS.primary}
                strokeWidth={1.75}
                fill="url(#methaneGrad)"
                name="Methane (ppb)"
                activeDot={{ r: 3, strokeWidth: 0 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </Panel>
      </div>
  ),

  // Hotspot ranking table
  hotspots: () => (
      <Panel
        flush
        title="Hotspot ranking"
        description="Top sites by methane concentration — select a row to inspect on the map"
        className="animate-fade-up"
      >
        <div className="overflow-x-auto scrollbar-thin">
          <table className="table-data min-w-[760px]">
            <thead>
              <tr>
                <th className="!pl-5 w-10">Rank</th>
                <th>Location</th>
                <th className="!text-right">CH₄</th>
                <th>Primary source</th>
                <th>Confidence</th>
                <th>Risk</th>
                <th className="!pr-5 text-right">Detected</th>
              </tr>
            </thead>
            <tbody>
              {sortedHotspots.slice(0, 8).map((h, i) => (
                <tr
                  key={h.id}
                  className="row-click"
                  onClick={() => navigate(`/map?lat=${h.latitude}&lng=${h.longitude}&name=${encodeURIComponent(h.name)}`)}
                >
                  <td className="num !pl-5 text-muted">{String(i + 1).padStart(2, '0')}</td>
                  <td>
                    <p className="font-medium">{h.name}</p>
                    <p className="text-[11px] text-muted">{h.state}</p>
                  </td>
                  <td className="num !text-right">
                    <span className="metric-value text-[13px]" style={{ color: RISK_COLORS[h.risk_level] }}>
                      {h.methane_index}
                    </span>
                    <span className="text-[10px] text-muted ml-1">{h.methane_unit}</span>
                  </td>
                  <td className="text-secondary">
                    {h.probable_source ? SOURCE_TYPE_LABELS[h.probable_source] : 'Unknown'}
                  </td>
                  <td className="num text-secondary">{h.confidence_score}%</td>
                  <td>
                    <span className="inline-flex items-center gap-1.5 capitalize text-secondary">
                      <span className="status-dot" style={{ backgroundColor: RISK_COLORS[h.risk_level] }} />
                      {h.risk_level}
                    </span>
                  </td>
                  <td className="mono-label text-muted !pr-5 text-right whitespace-nowrap">
                    {new Date(h.detection_timestamp).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
  ),

  // Weather conditions
  weather: () => (
      <Panel title="Weather conditions" description={`${currentWeather?.city ?? 'Network'} · ground stations`} className="animate-fade-up">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-[var(--color-border)] rounded-lg overflow-hidden border border-[var(--color-border)]">
          {[
            { label: 'Temperature', value: currentWeather ? `${currentWeather.temperature}°C` : '—' },
            { label: 'Wind speed', value: currentWeather ? `${currentWeather.wind_speed} km/h` : '—' },
            { label: 'Humidity', value: currentWeather ? `${currentWeather.humidity}%` : '—' },
            { label: 'Pressure', value: currentWeather ? `${currentWeather.pressure} hPa` : '—' },
          ].map((s) => (
            <div key={s.label} className="bg-[var(--color-surface)] px-4 py-3.5">
              <p className="kicker mb-1.5">{s.label}</p>
              <p className="metric-value text-[17px] leading-none">{s.value}</p>
            </div>
          ))}
        </div>
      </Panel>
  ),

  // AI insight
  insight: () =>
    aiResult ? (
        <Panel
          title="AI environmental brief"
          description={`AirSense · ${aiResult.modelVersion}`}
          className="animate-fade-up"
        >
          <div className="grid sm:grid-cols-3 gap-px bg-[var(--color-border)] rounded-lg overflow-hidden border border-[var(--color-border)] mb-4">
            <div className="bg-[var(--color-surface)] px-4 py-3.5">
              <p className="kicker mb-1.5">Risk score</p>
              <p className="metric-value text-[20px] leading-none" style={{ color: RISK_COLORS[aiResult.riskLevel] }}>
                {aiResult.riskScore}
                <span className="text-xs text-muted font-normal"> /100</span>
              </p>
            </div>
            <div className="bg-[var(--color-surface)] px-4 py-3.5">
              <p className="kicker mb-1.5">Confidence</p>
              <p className="metric-value text-[20px] leading-none">{aiResult.confidence}%</p>
            </div>
            <div className="bg-[var(--color-surface)] px-4 py-3.5">
              <p className="kicker mb-1.5">Probable source</p>
              <p className="text-[15px] font-medium leading-none pt-0.5">
                {SOURCE_TYPE_LABELS[aiResult.probableSources[0]?.source ?? 'unknown']}
              </p>
            </div>
          </div>

          <ul className="space-y-2">
            {aiResult.insights.slice(0, 3).map((insight, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm">
                <span className="w-3 h-px bg-primary-500 mt-[9px] flex-shrink-0" />
                <p className="text-secondary leading-relaxed">{insight}</p>
              </li>
            ))}
          </ul>
          <div className="mt-4 border-t border-[var(--color-border)] pt-3">
            <FreshnessStamp timestamp={loadedAt} label="Updated" />
          </div>
        </Panel>
    ) : null,
  };

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      <PageHeader
        title="Environmental Intelligence"
        description="Live overview of methane, air quality, weather and risk across India"
        meta={<FreshnessStamp timestamp={loadedAt} label="Network updated" />}
        actions={
          <>
            <DemoBadge show={isDemo} />

            {/* Section customization */}
            <div className="relative">
              <button
                onClick={() => setCustomizeOpen(!customizeOpen)}
                className="btn-secondary !py-1.5 !px-3 text-[13px] gap-1.5"
                aria-expanded={customizeOpen}
                aria-label="Customize dashboard sections"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Customize</span>
              </button>
              {customizeOpen && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setCustomizeOpen(false)} />
                  <div className="absolute top-full right-0 mt-1.5 w-64 surface shadow-popover z-40 py-2 animate-fade-in">
                    <p className="kicker px-3 pb-1.5">Dashboard sections</p>
                    <ul className="max-h-[300px] overflow-y-auto scrollbar-thin">
                      {(layout.order.length === DEFAULT_ORDER.length ? layout.order : DEFAULT_ORDER).map((id) => {
                        const isHidden = layout.hidden.includes(id);
                        const order = layout.order.length === DEFAULT_ORDER.length ? layout.order : DEFAULT_ORDER;
                        const idx = order.indexOf(id);
                        return (
                          <li key={id} className={`flex items-center gap-1 px-2 py-0.5 ${isHidden ? 'opacity-50' : ''}`}>
                            <input
                              type="checkbox"
                              checked={!isHidden}
                              onChange={() => toggleSection(id)}
                              aria-label={`Show ${SECTION_LABELS[id]}`}
                            />
                            <span className="text-[13px] flex-1 truncate">{SECTION_LABELS[id]}</span>
                            <button
                              onClick={() => moveSection(id, -1)}
                              disabled={idx === 0}
                              className="btn-ghost !p-1 disabled:opacity-25"
                              aria-label={`Move ${SECTION_LABELS[id]} up`}
                            >
                              <ArrowUp className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => moveSection(id, 1)}
                              disabled={idx === order.length - 1}
                              className="btn-ghost !p-1 disabled:opacity-25"
                              aria-label={`Move ${SECTION_LABELS[id]} down`}
                            >
                              <ArrowDown className="w-3 h-3" />
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </>
              )}
            </div>

            <Link to="/map" className="btn-primary !py-1.5 !px-3 text-[13px]">
              Open full map <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </>
        }
      />

      {visibleOrder.map((id) => (
        <Fragment key={id}>{renderSection[id]()}</Fragment>
      ))}
    </div>
  );
}

/**
 * Static geographic preview — data visualization, not decoration.
 * Restrained markers on a fine reference grid.
 */
function MiniMapPreview({ hotspots, aqiData }: { hotspots: Hotspot[]; aqiData: AqiObservation[] }) {
  return (
    <div
      className="relative h-[300px] bg-[var(--color-surface-2)]"
      style={{
        backgroundImage:
          'linear-gradient(var(--map-grid) 1px, transparent 1px), linear-gradient(90deg, var(--map-grid) 1px, transparent 1px)',
        backgroundSize: '24px 24px',
      }}
    >
      {/* AQI stations — hollow rings */}
      {aqiData.slice(0, 12).map((a) => {
        const x = ((a.longitude - 68) / (97 - 68)) * 100;
        const y = ((35 - a.latitude) / (35 - 6)) * 100;
        return (
          <span
            key={`aqi-${a.id}`}
            className="absolute w-2 h-2 rounded-full border-2 -translate-x-1/2 -translate-y-1/2"
            style={{ left: `${x}%`, top: `${y}%`, borderColor: getAqiCategory(a.aqi).color }}
          />
        );
      })}

      {/* Methane hotspots — sized by concentration */}
      {hotspots.slice(0, 12).map((h) => {
        const x = ((h.longitude - 68) / (97 - 68)) * 100;
        const y = ((35 - h.latitude) / (35 - 6)) * 100;
        const size = 6 + Math.min(Math.max((h.methane_index - 1850) / 55, 0), 8);
        return (
          <span
            key={h.id}
            className="absolute rounded-full -translate-x-1/2 -translate-y-1/2 ring-2 ring-[var(--color-surface-2)]"
            style={{
              left: `${x}%`,
              top: `${y}%`,
              width: `${size}px`,
              height: `${size}px`,
              backgroundColor: RISK_COLORS[h.risk_level],
              opacity: 0.88,
            }}
          />
        );
      })}

      {/* Legend */}
      <div className="absolute bottom-3 left-3 flex items-center gap-4 surface !rounded-md px-2.5 py-1.5 shadow-panel">
        <span className="flex items-center gap-1.5 mono-label uppercase text-muted">
          <span className="w-1.5 h-1.5 rounded-full bg-danger-500" /> Hotspot
        </span>
        <span className="flex items-center gap-1.5 mono-label uppercase text-muted">
          <span
            className="w-1.5 h-1.5 rounded-full border"
            style={{ borderColor: 'var(--color-good) var(--color-moderate) var(--color-critical) var(--color-severe)' }}
            title="Station color indicates AQI severity"
          /> AQI station
        </span>
      </div>
    </div>
  );
}
