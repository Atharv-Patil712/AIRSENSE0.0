import colors from 'tailwindcss/colors';

// Theme-aware utility aliases consume the same tokens as charts and panels.
const semantic = (token, textToken = token) => ({
  50: `color-mix(in srgb, var(${token}) 5%, var(--color-surface))`,
  100: `color-mix(in srgb, var(${token}) 12%, var(--color-surface))`,
  400: `var(${textToken})`,
  500: `var(${token})`,
  600: `var(${textToken})`,
});


/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // AirSense sky-blue identity; green is reserved for safe conditions.
        primary: colors.sky,
        accent: colors.sky,
        success: semantic('--color-good', '--color-good-text'),
        warning: semantic('--color-moderate', '--color-moderate-text'),
        danger: semantic('--color-critical', '--color-critical-text'),
        error: semantic('--color-critical', '--color-critical-text'),
        info: semantic('--color-primary-bg', '--color-primary-text'),
        prediction: semantic('--color-prediction', '--color-prediction-text'),
        // ── Cinematic surface (public experience at /) ──
        // Atomic values for the atmospheric storyboard. Kept here so the
        // palette is discoverable alongside the rest of the design system;
        // the experience itself consumes the scoped CSS variables in
        // index.css and uses these only where a Tailwind utility is clearer.
        cinema: {
          bg: '#05070D',
          soft: '#0B101A',
          raised: '#111827',
          accent: '#67E8F9',
          blue: '#38BDF8',
          ice: '#A5F3FC',
          indigo: '#818CF8',
          violet: '#C084FC',
          clean: '#5EEAD4',
          warn: '#FACC15',
          high: '#FB923C',
          severe: '#F43F5E',
        },
      },
      fontFamily: {
        sans: ['var(--font-body)'],
        body: ['var(--font-body)'],
        mono: ['var(--font-mono)'],
        display: ['var(--font-display)'],
      },
      letterSpacing: {
        tightest: '-0.03em',
        widest2: '0.12em',
      },
      boxShadow: {
        panel: 'var(--panel-shadow)',
        popover:
          '0 8px 24px -6px rgba(14, 17, 19, 0.14), 0 2px 6px -2px rgba(14, 17, 19, 0.08)',
        drawer: '-12px 0 40px rgba(14, 17, 19, 0.22)',
      },
      transitionTimingFunction: {
        out: 'cubic-bezier(0.25, 1, 0.5, 1)',
        // Decelerating curve used by the cinematic experience.
        cinema: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
      transitionDuration: {
        150: '150ms',
        250: '250ms',
      },
      spacing: {
        18: '4.5rem',
      },
      animation: {
        'fade-in': 'fadeIn 0.22s cubic-bezier(0.25, 1, 0.5, 1)',
        'fade-up': 'fadeUp 0.36s cubic-bezier(0.25, 1, 0.5, 1) both',
        'drawer-in': 'drawerIn 0.28s cubic-bezier(0.25, 1, 0.5, 1)',
        'overlay-in': 'overlayIn 0.2s ease-out',
        shimmer: 'shimmer 1.8s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(6px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        drawerIn: {
          from: { transform: 'translateX(24px)', opacity: '0' },
          to: { transform: 'translateX(0)', opacity: '1' },
        },
        overlayIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        shimmer: {
          '0%, 100%': { opacity: '0.55' },
          '50%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};
